import json
import boto3
import time
import logging
import os

def restartNodeJSApp(event, context):

    client_EC2 = boto3.client('ec2')
    client_ssm = boto3.client('ssm')
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    DB_CONNECTION_STRING = os.environ['DB_CONNECTION_STRING']

    listEC2=[]

    instances = client_EC2.describe_instances(
    Filters=[
        {
            'Name': 'tag:Name',
            'Values': [
                'UbuntuNodeJS'
            ],
            'Name': 'instance-state-name',
            'Values':[
                'running'
            ]
        }
    ]
    )
    
    for singleReservation in instances['Reservations']:
        for singleInstance in singleReservation['Instances']:
            listEC2.append(singleInstance['InstanceId'])

    response = client_ssm.send_command(
        InstanceIds=listEC2,
        DocumentName="AWS-RunShellScript",
        Parameters={"workingDirectory":["/usr/local/cloud-phoenix-kata"], 'commands': ['sudo su', 'PORT=8080 DB_CONNECTION_STRING="'+ DB_CONNECTION_STRING + '" node ./bin/www > stdout.txt 2> stderr.txt &'
        ]
        } 
        )
    logger.info('Run command executed !!')


    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
