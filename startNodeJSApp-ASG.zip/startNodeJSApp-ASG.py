import json
import boto3
import time
import logging
import os

def startNodeJS(event, context):
    
    client_CodePipeline = boto3.client('codepipeline')
    client_EC2 = boto3.client('ec2')
    client_SSM = boto3.client('ssm')
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    DB_CONNECTION_STRING = os.environ['DB_CONNECTION_STRING']
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    
    startPipeline = client_CodePipeline.start_pipeline_execution(
    name='cloud-phoenix-kata-pipeline'
    )
    
    pipelineID = startPipeline['pipelineExecutionId']

    time.sleep(60)
    
    listEC2=[]
    
    instances = client_EC2.describe_instances(
    Filters=[
        {
            'Name': 'tag:Name',
            'Values': [
                'UbuntuNodeJS'
            ],
            'Name': 'instance-state-name',
            'Values':[
                'running'
            ]
        }
    ]
    )
    
    for singleReservation in instances['Reservations']:
        for singleInstance in singleReservation['Instances']:
            listEC2.append(singleInstance['InstanceId'])
    
    check=0
    
    while check==0:
        
        pipelineState = client_CodePipeline.get_pipeline_execution(
        pipelineName='cloud-phoenix-kata-pipeline',
        pipelineExecutionId=pipelineID
        )
        
        pipelineStatus = pipelineState['pipelineExecution']
        print(pipelineStatus)       
        
        if pipelineStatus['status']=='InProgress':
            time.sleep(30)    
            check=0
            logger.info('Codepipeline in progress !!')
    
        if pipelineStatus['status']=='Succeeded':
        # Run command
            response = client_SSM.send_command(
                InstanceIds=listEC2,
                DocumentName="AWS-RunShellScript",
                Parameters={"workingDirectory":["/usr/local/cloud-phoenix-kata"], 'commands': ['sudo su', 'npm install','PORT=8080 DB_CONNECTION_STRING="'+ DB_CONNECTION_STRING + '" node ./bin/www > stdout.txt 2> stderr.txt &'
                ]
                } 
                )
            check=1
            logger.info('Run command executed !!')
                        
        if pipelineStatus['status']=='Failed':
            check=0
            logger.info('Codepipeline is Failed !!')
            
